/*
 * Copyright (C) 2020 LTN Global Communications, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#ifndef __GST_FDKAAC_H__
#define __GST_FDKAAC_H__

#include <gst/audio/audio.h>

#include <fdk-aac/FDK_audio.h>

G_BEGIN_DECLS

typedef struct {
  gint channels;
  CHANNEL_MODE mode;
  GstAudioChannelPosition positions[8];
} GstFdkAacChannelLayout;

extern const GstFdkAacChannelLayout channel_layouts[];

G_END_DECLS

#endif /* __GST_FDKAAC_H__ */
